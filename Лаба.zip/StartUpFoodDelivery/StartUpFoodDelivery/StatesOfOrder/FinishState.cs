namespace StartUpFoodDelivery;

public class FinishState: IState
{
    public void GetInfoOfOrder()
    {
        Console.WriteLine("\n Сделанно!");
    }
}