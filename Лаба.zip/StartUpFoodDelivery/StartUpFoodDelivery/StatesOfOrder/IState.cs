namespace StartUpFoodDelivery;

public interface IState
{
    public void GetInfoOfOrder();
}