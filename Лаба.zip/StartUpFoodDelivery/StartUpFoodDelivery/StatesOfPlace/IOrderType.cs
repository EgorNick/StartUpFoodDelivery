using StartUpFoodDelivery.StatesOfPlace;

namespace StartUpFoodDelivery;

public interface IOrderType
{
    public void GetInfoOfPlace();
}